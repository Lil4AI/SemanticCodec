import os
import json
import zipfile
import io
import time
import random
from flask import Flask, request, jsonify, send_file, render_template
from werkzeug.utils import secure_filename
from PIL import Image, ImageOps
import numpy as np
import cv2
import piexif
import torch
from transformers import BlipProcessor, BlipForConditionalGeneration
from diffusers import StableDiffusionControlNetInpaintPipeline, ControlNetModel, UniPCMultistepScheduler
from rembg import remove

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# --- Global Models ---
models_loaded = False
blip_processor = None
blip_model = None
sd_pipeline = None

def init_models():
    global models_loaded, blip_processor, blip_model, sd_pipeline
    if models_loaded: return
    
    print("Loading AI Models... This might take a while on first run.")
    device = "cuda" if torch.cuda.is_available() else "cpu"
    
    try:
        # 1. BLIP for captioning
        blip_processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-large")
        blip_model = BlipForConditionalGeneration.from_pretrained(
            "Salesforce/blip-image-captioning-large", 
            torch_dtype=torch.float16 if device=="cuda" else torch.float32
        ).to(device)

        # 2. ControlNet & SD Inpainting setup
        if device == "cuda":
            controlnet = ControlNetModel.from_pretrained("lllyasviel/sd-controlnet-canny", torch_dtype=torch.float16)
            sd_pipeline = StableDiffusionControlNetInpaintPipeline.from_pretrained(
                "runwayml/stable-diffusion-inpainting",
                controlnet=controlnet,
                torch_dtype=torch.float16,
                safety_checker=None
            )
            sd_pipeline.scheduler = UniPCMultistepScheduler.from_config(sd_pipeline.scheduler.config)
            sd_pipeline.enable_model_cpu_offload() # VRAM optimization
        else:
            controlnet = ControlNetModel.from_pretrained("lllyasviel/sd-controlnet-canny")
            sd_pipeline = StableDiffusionControlNetInpaintPipeline.from_pretrained(
                "runwayml/stable-diffusion-inpainting",
                controlnet=controlnet,
                safety_checker=None
            )
            sd_pipeline.to("cpu")
            
        models_loaded = True
        print("Models loaded successfully.")
    except Exception as e:
        print(f"Error loading models: {e}")
        # Allow server to start without models for testing the UI

def generate_caption(image):
    if not models_loaded: return "A photo of a background"
    inputs = blip_processor(image, return_tensors="pt").to(blip_model.device, blip_model.dtype)
    out = blip_model.generate(**inputs, max_new_tokens=40)
    return blip_processor.decode(out[0], skip_special_tokens=True)

def generate_canny_edge(image_np, low_threshold=100, high_threshold=200):
    gray = cv2.cvtColor(image_np, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, low_threshold, high_threshold)
    return edges

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/encode', methods=['POST'])
def encode_image():
    init_models()
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    mode = request.form.get('mode', 'Standard')
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
        
    try:
        # Load Original Image
        original_img = Image.open(file).convert("RGB")
        width, height = original_img.size
        
        # 1. Background Separation using rembg
        # remove() automatically generates RGBA image where background is transparent
        fg_rgba = remove(original_img)
        
        # Split into RGB and Alpha
        fg_color = fg_rgba.convert("RGB")
        fg_alpha = fg_rgba.split()[3]
        
        # Invert alpha to get background mask (255 where background is, 0 where object is)
        bg_mask = ImageOps.invert(fg_alpha)
        
        # Create a background-only image for analysis (fill foreground with black or average color)
        bg_only = Image.composite(original_img, Image.new("RGB", original_img.size, (0,0,0)), bg_mask)
        
        # 2. Extract Background Features
        caption = generate_caption(bg_only)
        
        # Generate Thumb (256x256, Quality 5)
        thumb = original_img.copy()
        thumb.thumbnail((256, 256))
        
        # Generate Canny Edge (1bit)
        edge_np = generate_canny_edge(np.array(original_img))
        edge_img = Image.fromarray(edge_np).convert("1")
        
        # 3. Save components to memory buffs
        fg_color_io = io.BytesIO()
        fg_color.save(fg_color_io, format='WEBP', quality=85, method=6) # Lossy
        
        fg_alpha_io = io.BytesIO()
        fg_alpha.save(fg_alpha_io, format='WEBP', lossless=True) # Lossless
        
        thumb_io = io.BytesIO()
        thumb.save(thumb_io, format='JPEG', quality=8) # Quality 5-10
        
        edge_io = io.BytesIO()
        edge_img.save(edge_io, format='PNG')
        
        # 4. Create Manifest
        seed = random.randint(0, 2**32 - 1)
        manifest = {
            "width": width,
            "height": height,
            "prompt": caption,
            "random_seed": seed,
            "model_version": "stable-diffusion-inpainting-1.5_controlnet-canny",
            "encoded_mode": mode
        }
        
        # 5. Package as ZIP (.semic)
        zip_io = io.BytesIO()
        with zipfile.ZipFile(zip_io, 'w', zipfile.ZIP_DEFLATED) as zipf:
            zipf.writestr('manifest.json', json.dumps(manifest))
            zipf.writestr('fg_color.webp', fg_color_io.getvalue())
            zipf.writestr('fg_alpha.webp', fg_alpha_io.getvalue())
            zipf.writestr('thumb.jpg', thumb_io.getvalue())
            zipf.writestr('edge_canny.png', edge_io.getvalue())
            
        zip_io.seek(0)
        
        return send_file(
            zip_io,
            mimetype='application/zip',
            as_attachment=True,
            download_name=f'encoded_{int(time.time())}.semic'
        )
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/decode', methods=['POST'])
def decode_image():
    init_models()
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
        
    file = request.files['file']
    decode_mode = request.form.get('mode', 'Standard')
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
        
    try:
        # Check if it's a .semic file
        if file.filename.endswith('.semic'):
            with zipfile.ZipFile(file, 'r') as zipf:
                manifest = json.loads(zipf.read('manifest.json'))
                fg_color = Image.open(io.BytesIO(zipf.read('fg_color.webp'))).convert("RGB")
                fg_alpha = Image.open(io.BytesIO(zipf.read('fg_alpha.webp'))).convert("L")
                thumb = Image.open(io.BytesIO(zipf.read('thumb.jpg'))).convert("RGB")
                try:
                    edge_canny = Image.open(io.BytesIO(zipf.read('edge_canny.png'))).convert("L")
                except:
                    edge_canny = None
        else:
            # Fallback if someone uploaded an image with EXIF (not implemented fully for extraction here,
            # but would follow similar logic)
            return jsonify({'error': 'Only .semic files are supported in this demo endpoint'}), 400
            
        width = manifest["width"]
        height = manifest["height"]
        prompt = manifest["prompt"]
        seed = manifest["random_seed"]
        
        # Reconstruct base image from thumb
        base_bg = thumb.resize((width, height), Image.LANCZOS)
        
        # The mask where we want AI to paint (background = 255, foreground = 0)
        bg_mask = ImageOps.invert(fg_alpha)
        
        # If Lite mode: AI generation skipped. Use scaled thumb as background.
        if decode_mode == 'Lite' or not models_loaded:
            result_img = base_bg.copy()
            # Paste foreground
            result_img.paste(fg_color, (0, 0), fg_alpha)
            
        else:
            # Prepare AI generation
            generator = torch.Generator(device="cpu" if not torch.cuda.is_available() else "cuda").manual_seed(seed)
            
            # Upscale edge canny to correct dims
            control_image = None
            controlnet_scale = 0.0
            steps = 20
            
            if decode_mode == 'HighFi' and edge_canny is not None:
                control_image = edge_canny.resize((width, height), Image.NEAREST)
                controlnet_scale = 1.0 # Full ControlNet guide
                steps = 50
            elif decode_mode == 'Standard':
                # Create a blank edge image or set scale to 0
                control_image = Image.new("L", (width, height), 0)
                controlnet_scale = 0.0
                steps = 20
            else:
                 control_image = Image.new("L", (width, height), 0)
                
            # Resize constraints (SD likes multiples of 8)
            proc_w = (width // 8) * 8
            proc_h = (height // 8) * 8
            
            # Since VRAM is limited, we might want to scale down during inference if too large
            if proc_w * proc_h > 1024 * 1024: # max 1MP limit for basic VRAM
                scale = (1024 * 1024) ** 0.5 / (proc_w * proc_h) ** 0.5
                proc_w = int((proc_w * scale) // 8) * 8
                proc_h = int((proc_h * scale) // 8) * 8
                
            # サムネイルのJPEGブロックノイズをAIが拾ってしまうのを防ぐため強くぼかす
            from PIL import ImageFilter
            gen_bg = base_bg.filter(ImageFilter.GaussianBlur(radius=15)).resize((proc_w, proc_h), Image.LANCZOS)
            gen_mask = bg_mask.resize((proc_w, proc_h), Image.LANCZOS)
            gen_control = control_image.resize((proc_w, proc_h), Image.NEAREST)
            
            # Run SD Pipeline
            out_bg = sd_pipeline(
                prompt=prompt,
                image=gen_bg,
                mask_image=gen_mask,
                control_image=gen_control,
                num_inference_steps=steps,
                strength=0.95,
                generator=generator,
                controlnet_conditioning_scale=controlnet_scale,
                guidance_scale=7.5
            ).images[0]
            
            # Resize back to original
            out_bg = out_bg.resize((width, height), Image.LANCZOS)
            
            # Paste true foreground (ロスレスWebP経由のため極めて高品質)
            result_img = out_bg.copy()
            result_img.paste(fg_color, (0, 0), fg_alpha)
            
        # Add Exif Data to prevent Semantic Drift
        exif_dict = {"0th": {}, "Exif": {}, "GPS": {}, "1st": {}, "thumbnail": None}
        manifest_str = json.dumps({
            "random_seed": seed,
            "model_version": manifest["model_version"],
            "prompt": prompt
        })
        exif_dict["Exif"][piexif.ExifIFD.UserComment] = manifest_str.encode("utf-8")
        exif_bytes = piexif.dump(exif_dict)
        
        # Save to IO
        out_io = io.BytesIO()
        result_img.save(out_io, format='JPEG', quality=95, exif=exif_bytes)
        out_io.seek(0)
        
        return send_file(
            out_io,
            mimetype='image/jpeg',
            as_attachment=True,
            download_name=f'decoded_{decode_mode}.jpg'
        )

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
