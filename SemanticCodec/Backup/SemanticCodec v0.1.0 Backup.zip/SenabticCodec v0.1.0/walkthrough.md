# Semantic Codec Prototype: 実装完了レポート

設計書（Implementation Plan）に沿って、Semantic Codecの全実装が完了しました。

## 完了した項目

### 1. 独自エンコーダパイプラインの実装 (Encoder)
`POST /api/encode` において、以下の仕様を満たす `.semic` ファイルの生成フローを実装しました。
- `rembg` による前景・背景分離
- 前景のWebP分離保存: **`fg_color.webp` (Lossy)** と **`fg_alpha.webp` (Lossless)**
- 背景からの超低品質サムネイル **`thumb.jpg` (256x256 / Q5-10)** 生成
- ControlNet向けの構造ガイド **`edge_canny.png` (1bit Canny)** 生成
- BLIP による背景自動プロンプト生成
- 生成パラメータ (`random_seed`, `model_version`, プロンプト等) を収録した **`manifest.json`** を含めZIPパッケージ化

### 2. 再構築デコーダパイプラインの実装 (Decoder)
`POST /api/decode` において、指定されたプロファイルによる再構成フローを実装しました。
- **Lite**: AI生成をスキップし、超低品質サムネイルをベースに即座に表示。
- **Standard**: Stable Diffusion Inpainting を用いて、20 steps でバランス良く復元。
- **HighFi**: Stable Diffusion Inpaintingに加え、`edge_canny.png` を ControlNet Canny に入力し構造を精密に維持（50 steps）。
- 復元された画像の **EXIF領域 (`piexif`)** に `random_seed` と `model_version` などのメタデータを埋め込み、世代劣化 (Semantic Drift) を防止。

### 3. モダンでリッチなWeb UI
FlaskのテンプレートおよびVanilla CSSを用いて、プレミアム感のあるUIを構築しました。
- ドラッグ＆ドロップ対応の洗練されたアップロードUI
- ダークモード ＋ Glassmorphism による奥行きのあるデザイン
- 圧縮プロファイル (Lite / Standard / HighFi) の直感的な選択UI

---

## トレードオフや技術的決定

> [!NOTE]
> GPUがない環境でも一応動作可能にするため、AIモデルロード時にCUDAの利用可否を判定するフォールバック処理を入れています。ただし、CPU環境ではDecoder（Stable Diffusion）の処理に数十分かかる場合があります。

> [!TIP]
> `StableDiffusionControlNetInpaintPipeline` では、VRAM(8GB水準)でのクラッシュを防ぐため `enable_model_cpu_offload()` を適用し、省メモリ化を図っています。

---

## 実行方法

アプリを起動するには、以下の手順に従ってください。

```powershell
# 1. プロジェクトディレクトリへ移動
cd "C:\Users\Lil4C\.gemini\antigravity\scratch\SemanticCodec"

# 2. 仮想環境の作成と有効化 (推奨)
python -m venv venv
.\venv\Scripts\activate

# 3. 依存ライブラリのインストール
pip install -r requirements.txt

# 4. アプリケーションの起動
python app.py
```
起動したら、ブラウザで `http://localhost:5000` にアクセスしてください。

> [!WARNING]
> 初回にEncoderかDecoderを実行すると、各種AIモデル (Stable Diffusion, ControlNet, BLIP, rembg等) 約8〜10GB分のダウンロードがバックグラウンドで行われます。ロードが完了するまでしばらくお待ちください。
