# Semantic Codec — 生成的画像圧縮プロトタイプ

全体的なアーキテクチャおよびFlaskを用いたUI構成に基づいた、Semantic Codecの実装計画・設計書です。直近の議論で合意した以下の3点を完全に網羅し、反映しています。

1. **.semic フォーマットの統一**
2. **モード選択機能の追加**
3. **マニフェストとメタデータの徹底**

---

## 1. システムアーキテクチャ

システムは「Encoder（符号化）」と「Decoder（復号化）」の2つの主要コンポーネントで構成されるWebアプリケーション（Flaskベース）です。

### 1.1 Encoder ワークフロー
1. **前景分離**: `rembg` (U2Net) を用いて前景と背景を分離。
2. **前景圧縮**: 
    - `fg_color.webp`: 前景のRGBテクスチャを **非可逆WebP (Lossy)** で保存。
    - `fg_alpha.webp`: 前景の透過マスクを **可逆WebP (Lossless)** で保存。
      *(旧仕様 `foreground.png` は廃止)*
3. **背景解析**:
    - **言語化**: `BLIP` モデルで背景プロンプトを生成。
    - **特徴抽出**: 低品質の **256x256 JPEG (`thumb.jpg` / Quality 5-10)** を初期ノイズガイドとして生成。*(旧仕様 64x64 から変更)*
    - **構造抽出**: ControlNet用エッジガイドとして、**`edge_canny.png` (1bit Canny PNG)** を追加生成。
4. **パッケージング**: メタデータ (`manifest.json`) と共にZIP形式で圧縮し、`.semic` ファイルを生成。

### 1.2 Decoder ワークフロー
1. **データ解凍**: `.semic` または画像内の EXIF メタデータから各要素を抽出。
2. **背景生成 (Generative Inpainting)**:
    - ユーザーが指定した**展開モード**（Lite / Standard / HighFi）に応じてプロセスを切り替え。
    - `Stable Diffusion Inpainting 1.5` および **ControlNet (Canny)** を使用。
    - 抽出した `random_seed` と `model_version` をモデルに渡し、確定的な再構成を実行。
3. **合成 & 出力**: 生成された背景に、再構成したWebP前景 (`fg_color` + `fg_alpha`) を統合。

---

## 2. データフォーマット仕様 (.semic)

ZIPベースの独自形式内部構造：

```text
image.semic (ZIP)
  ├── manifest.json   # [必須] 画像サイズ、プロンプト、random_seed、model_version 等
  ├── fg_color.webp   # 前景RGB (非可逆・Lossy WebP)
  ├── fg_alpha.webp   # 前景Alpha (ロスレス・Lossless WebP)
  ├── thumb.jpg       # 初期ノイズ・背景ガイド (256x256, Quality 5-10の超低品質JPEG)
  └── edge_canny.png  # ControlNet用背景構造エッジガイド (1bit Canny PNG)
```

---

## 3. モード選択機能 (UI / API仕様)

APIのリクエスト、およびフロントエンドのUIに、処理内容を制御する3つのモードを追加します。

| モード | ユースケース・背景復元手法 | 速度・品質特性 |
|---|---|---|
| **Lite** | **AI生成スキップ**（サムネイルのアップスケールや簡易補間のみ） | 高速・最小リソース |
| **Standard** | **SD Inpainting (20 steps)** による標準的な背景再構成 | 推奨・汎用バランス |
| **HighFi** | **SD + ControlNet** を用いた最高品質の背景構造復元 | 最高品質・構造維持 |

---

## 4. マニフェストとメタデータの徹底 (Semantic Drift対策)

再圧縮と再構成を繰り返すことによる生成物の「世代劣化 (Semantic Drift)」を厳密に防ぐため、以下の要件を徹底します。

1. **`manifest.json` への必須記録**
   Encoder生成時、必ず `random_seed`（生成に使用するシード値）と `model_version`（SDやControlNetのバージョン情報）を含める。
2. **EXIF領域へのメタデータ埋め込み (`piexif`)**
   Decoderでの復元画像書き出し時、画像の EXIF データに同 `random_seed` と `model_version` を必ず埋め込む。これにより、`.semic` ファイルが失われても画像単体から同一条件下での再構成が可能となる。

---

## Proposed Changes (ファイル構成と実装方針)

本設計書を踏まえ、プロジェクトディレクトリに以下の構成で実装を行います。

### [NEW] `requirements.txt`
Pythonライブラリ定義 (`flask`, `rembg`, `diffusers`, `transformers`, `piexif`, `opencv-python`, 等)。

### [NEW] `app.py`
Flaskを用いたメインバックエンドサーバー。
- `POST /api/encode`: 画像とモード (Lite/Standard/HighFi) を受け取り、上記の `Encoder` パイプラインを実行、`.semic` を返却する。
- `POST /api/decode`: `.semic` または画像本体を受け取り、指定モードにて `Decoder` パイプラインを実行。生成画像(EXIF付与済)を返却する。

### [NEW] `templates/index.html` & `static/`
- **UI:** Encode / Decode を切り替えるタブ画面。
- **機能:** モード選択用のドロップダウンまたはオプションボタン (Lite / Standard / HighFi) の配置、結果のプレビュー表示。

---

## User Review Required

> [!IMPORTANT]
> ご指摘いただいた3点（フォーマットの詳細変更・モード選択の追加・メタデータ埋め込みの徹底）を反映した設計書を作成しました。内容に不足や相違がないかご確認ください。本仕様にて実装（コーディング）に進んでよろしいでしょうか？
