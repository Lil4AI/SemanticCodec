import torch

print("=== 犯人特定テスト ===")
print("CUDA (GPU) は使える状態か？:", torch.cuda.is_available())

if torch.cuda.is_available():
    print("認識しているGPU:", torch.cuda.get_device_name(0))
else:
    print("GPUが認識されていません！CPU版のPyTorchが入っています。、またはCUDAがシステムから見えていません。")
