document.addEventListener('DOMContentLoaded', () => {
    // Tabs
    const tabBtns = document.querySelectorAll('.tab-btn');
    const panels = document.querySelectorAll('.panel');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tabBtns.forEach(b => b.classList.remove('active'));
            panels.forEach(p => p.classList.remove('active'));
            
            btn.classList.add('active');
            document.getElementById(btn.dataset.target).classList.add('active');
        });
    });

    // File Upload Handlers
    function setupDropzone(dropzoneId, inputId) {
        const dropzone = document.getElementById(dropzoneId);
        const input = document.getElementById(inputId);
        const textElem = dropzone.querySelector('.upload-text');
        
        dropzone.addEventListener('click', () => input.click());
        
        dropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropzone.classList.add('dragover');
        });
        
        dropzone.addEventListener('dragleave', () => {
            dropzone.classList.remove('dragover');
        });
        
        dropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropzone.classList.remove('dragover');
            
            if (e.dataTransfer.files.length) {
                input.files = e.dataTransfer.files;
                updateFileName(input, textElem, dropzoneId);
            }
        });
        
        input.addEventListener('change', () => {
            updateFileName(input, textElem, dropzoneId);
        });
    }
    
    function updateFileName(input, textElem, dropzoneId) {
        if (input.files.length > 0) {
            textElem.textContent = input.files[0].name;
            textElem.classList.add('file-selected');
        } else {
            textElem.textContent = dropzoneId === 'encode-dropzone' ? 'Drag & Drop an image here or click to browse' : 'Drag & Drop a .semic file here';
            textElem.classList.remove('file-selected');
        }
    }

    setupDropzone('encode-dropzone', 'encode-file');
    setupDropzone('decode-dropzone', 'decode-file');

    // Forms Handlers
    const encodeForm = document.getElementById('encode-form');
    const encodeBtn = document.getElementById('encode-btn');
    const encodeLoader = encodeBtn.querySelector('.loader');

    encodeForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const fileInput = document.getElementById('encode-file');
        
        if (!fileInput.files.length) {
            alert('Please select an image file first.');
            return;
        }
        
        const mode = document.querySelector('input[name="encode-mode"]:checked').value;
        const formData = new FormData();
        formData.append('file', fileInput.files[0]);
        formData.append('mode', mode);

        setLoading(encodeBtn, encodeLoader, true);
        
        try {
            const res = await fetch('/api/encode', {
                method: 'POST',
                body: formData
            });
            
            if (!res.ok) {
                const err = await res.json();
                throw new Error(err.error || 'Server error');
            }
            
            // Download the file
            const blob = await res.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = `compressed_${mode}.semic`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            
        } catch (err) {
            alert(`Error formatting file: ${err.message}`);
        } finally {
            setLoading(encodeBtn, encodeLoader, false);
        }
    });

    const decodeForm = document.getElementById('decode-form');
    const decodeBtn = document.getElementById('decode-btn');
    const decodeLoader = decodeBtn.querySelector('.loader');
    const resultContainer = document.getElementById('result-container');
    const resultImage = document.getElementById('result-image');
    const downloadBtn = document.getElementById('download-btn');

    decodeForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const fileInput = document.getElementById('decode-file');
        
        if (!fileInput.files.length) {
            alert('Please select a .semic file first.');
            return;
        }
        
        const mode = document.querySelector('input[name="decode-mode"]:checked').value;
        const formData = new FormData();
        formData.append('file', fileInput.files[0]);
        formData.append('mode', mode);

        setLoading(decodeBtn, decodeLoader, true);
        resultContainer.style.display = 'none';
        
        try {
            const res = await fetch('/api/decode', {
                method: 'POST',
                body: formData
            });
            
            if (!res.ok) {
                const err = await res.json();
                throw new Error(err.error || 'Server error');
            }
            
            const blob = await res.blob();
            const url = window.URL.createObjectURL(blob);
            resultImage.src = url;
            downloadBtn.href = url;
            downloadBtn.download = `reconstructed_${mode}.jpg`;
            
            resultContainer.style.display = 'block';
            
        } catch (err) {
            alert(`Error decoding file: ${err.message}`);
        } finally {
            setLoading(decodeBtn, decodeLoader, false);
        }
    });

    function setLoading(btn, loader, isLoading) {
        btn.disabled = isLoading;
        btn.querySelector('.btn-text').style.opacity = isLoading ? '0' : '1';
        loader.style.display = isLoading ? 'block' : 'none';
        loader.style.position = isLoading ? 'absolute' : 'static';
    }
});
